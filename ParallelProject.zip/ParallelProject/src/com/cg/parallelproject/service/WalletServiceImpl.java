package com.cg.parallelproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.parallelproject.dao.WalletRepo;
import com.cg.parallelproject.dto.Customer;
import com.cg.parallelproject.dto.Transaction;
import com.cg.parallelproject.exception.InsufficientBalanceException;
import com.cg.parallelproject.exception.InvalidInputException;
@Service("service")
@Transactional
public class WalletServiceImpl implements WalletService{
	@Autowired
	WalletRepo repo;

	@Override
	public Customer createAccount(String name, String mobileno, double amount) {
		// TODO Auto-generated method stub
		Customer c1=repo.findOne(mobileno);
		if(c1==null)
		{
		//Wallet w=new Wallet(amount);
		Customer c=new Customer(name,mobileno,amount);
		if(repo.createNewDetails(c))
		return c;
		else
			throw new InvalidInputException("Invalid");
		}
		else 
			throw new InvalidInputException("Number already Exists");
	}

	@Override
	public Customer showBalance(String mobileno) {
		// TODO Auto-generated method stub
		Customer c=repo.findOne(mobileno);
		if(c!=null)
		return c;
		else
			throw new InvalidInputException("The number does not exist Please enter registered mobile number");
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, double amount) {
		// TODO Auto-generated method stub
		String type="TRANSFER";
		Customer c=repo.findOne(sourceMobileNo);
		Customer c1=repo.findOne(targetMobileNo);
		if(amount<=0)
			throw new InsufficientBalanceException("Please enter amount more than 0 amount cannot be less than or equal to zero");
		if(c==null)
			throw new InvalidInputException("Sender Number not found Please enter registered mobile number");
		if(c1==null)
			throw new InvalidInputException("Reciever Number not registered");
		if(c!=null&&c1!=null)
		{
		withdrawAmount(sourceMobileNo,amount);
		depositAmount(targetMobileNo,amount);
		Transaction t1=new Transaction(sourceMobileNo,type,amount);
		Transaction t2=new Transaction(targetMobileNo,type,-amount);
		repo.addTransaction(t1);
		repo.addTransaction(t2);
		return c;
		}
		else
		throw new InvalidInputException("Transfer failed");
	}

	@Override
	public Customer depositAmount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		String type="DEPOSIT";
		Customer cu=repo.findOne(mobileNo);
		//Wallet w=cu.getWallet();
		if(amount<=0)
			throw new InsufficientBalanceException("Please enter amount more than 0 amount cannot be less than or equal to zero");
		if(cu!=null)
		{
		cu.setBalance(cu.getBalance()+amount);
		repo.save(cu);
		Transaction t1=new Transaction(mobileNo,type,amount);
		repo.addTransaction(t1);
		return cu;
		}
		throw new InvalidInputException("Number not found Please enter registered mobile number");
	}

	@Override
	public Customer withdrawAmount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		String type="WITHDRAW";
		Customer cu=repo.findOne(mobileNo);
		if(cu==null)
			throw new InvalidInputException("Number not found Please enter registered mobile number");
		//Wallet w=cu.getWallet();
		if((cu.getBalance()-amount)>=500)
		{
		cu.setBalance(cu.getBalance()-amount);
		repo.save(cu);
		Transaction t1=new Transaction(mobileNo,type,amount);
		repo.addTransaction(t1);
		return cu;
		}
		else
			throw new InsufficientBalanceException("Insufficient Balance in  your account cannot deduct money because we need to maintain minimum of 500 balance");
	}

	@Override
	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateNumber(String number) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateBalance(double number) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean findNumber(String mobile) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isNewMobile(String mob) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isAvailableMobile(String mob) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Transaction> getAllTransactions(String mobile) {
		// TODO Auto-generated method stub
		Customer c=repo.findOne(mobile);
		if(c==null)
			throw new InvalidInputException("Mobile number is not registered, Enter Registered Mobile number");
		 List<Transaction> l=repo.getAllTransaction(mobile);
		 return l;

	}

}
