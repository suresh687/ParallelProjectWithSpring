package com.cg.parallelproject.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.parallelproject.dto.Customer;
import com.cg.parallelproject.dto.Transaction;
import com.cg.parallelproject.exception.InvalidInputException;
import com.cg.parallelproject.service.WalletService;

@Controller
public class WalletController {
	@Autowired
	WalletService service;
	@RequestMapping(value="/index")
	public String index()
	{
		return "index";
	}
	@RequestMapping(value="/home")
	public String home(@ModelAttribute("my") Customer c)
	{
		return "createaccount";
	}
	@RequestMapping(value="create account",method=RequestMethod.POST)
	public ModelAndView  createacc(@Valid@ModelAttribute("my") Customer c,BindingResult res)
	{
		Customer cus=null;
		if(res.hasErrors())
			return new ModelAndView("createaccount");
		else
		{
			try
			{
			cus=service.createAccount(c.getName(),c.getMobileNo(),c.getBalance());
		
			}
			catch(InvalidInputException e)
			{
				System.out.println(e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			return new  ModelAndView("showbal","temp",cus);
		}
	}
	@RequestMapping(value="deposit")
	public String callDeposit(@ModelAttribute("d") Customer c)
	{
		return "deposit";
	}
	@RequestMapping(value="depositamount")
	public ModelAndView  deposit(@ModelAttribute("d") Customer c)
	{
		Customer cus=null;
			try
			{
			cus=service.depositAmount(c.getMobileNo(),c.getBalance());
			System.out.println("Successful");
		
			}
			catch(InvalidInputException e)
			{
				System.out.println(e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			return new  ModelAndView("showbal","temp",cus);
	}
	@RequestMapping(value="show")
	public String callshow(@ModelAttribute("e") Customer c)
	{
		return "showbalance";
	}
	@RequestMapping(value="show balance")
	public ModelAndView  showcustomer(@ModelAttribute("e") Customer c)
	{
		Customer cus = null;	
		try
			{
			 cus=service.showBalance(c.getMobileNo());
			System.out.println("Successful showed");
			
		
			}
			catch(InvalidInputException e)
			{
				System.out.println(e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			return new ModelAndView("showbal","temp",cus);
	}
	@RequestMapping(value="withdraw")
	public String callWithdraw(@ModelAttribute("w") Customer c)
	{
		return "withdraw";
	}
	@RequestMapping(value="withdrawamount")
	public ModelAndView  withdraw(@ModelAttribute("w") Customer c)
	{
		Customer cus=null;
			try
			{
			cus=service.withdrawAmount(c.getMobileNo(),c.getBalance());
			System.out.println("Successful withdraw");
		
			}
			catch(InvalidInputException e)
			{
				System.out.println(e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			return new ModelAndView("showbal","temp",cus);
	}
	@RequestMapping(value="transfer")
	public String calltransfer(@ModelAttribute("t") Customer c)
	{
		return "transfer";
	}
	@RequestMapping(value="transferfund")
	public ModelAndView transfer(@ModelAttribute("t") Customer c)
	{
		Customer cus=null;
		try
		{
			System.out.println(c.getMobileNo());
			String[] s=c.getMobileNo().split(",");
			
			
		cus=service.fundTransfer(s[0],s[1],c.getBalance());
		System.out.println("Successful withdraw"+s[1]+" des"+s[1]);
	
		}
		catch(InvalidInputException e)
		{
			System.out.println(e.getMessage());
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return new ModelAndView("showbal","temp",cus);
	}
	@RequestMapping(value="print")
	public String callprint(@ModelAttribute("p") Transaction c)
	{
		return "transactions";
	}
	@RequestMapping(value="show transactions")
	public ModelAndView transactions(@ModelAttribute("p") Transaction c)
	{
		List<Transaction> allTran= null;	
		try
			{
			allTran=service.getAllTransactions(c.getMobileNo());
			System.out.println("Successful showed");
			System.out.println(allTran);
			
		
			}
			catch(InvalidInputException e)
			{
				System.out.println(e.getMessage());
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			return new ModelAndView("showtransactions","data",allTran);
	}
	
	

}
