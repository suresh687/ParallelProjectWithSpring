package com.cg.parallelproject.dto;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="transactions")
public class Transaction {
	
	String mobileNo;
	String tranType;
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	int tranId;
	Date tranDate;
	double balance;
	public Transaction()
	{
		
	}
	public Transaction(String mobileNo, String tranType, double balance) {
		super();
		this.mobileNo = mobileNo;
		this.tranType = tranType;
		this.tranDate = new Date();
		this.balance = balance;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getTranType() {
		return tranType;
	}
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	public int getTranId() {
		return tranId;
	}
	public void setTranId(int tranId) {
		this.tranId = tranId;
	}
	public Date getTranDate() {
		return tranDate;
	}
	public void setTranDate(Date tranDate) {
		this.tranDate = tranDate;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return " TRANSACTION ID: " + tranId+" TRANSACTION TYPE: " + tranType
				+ " TRANSACTION DATE: " + tranDate
				+ " AMOUNT: " + balance;
	}

}
